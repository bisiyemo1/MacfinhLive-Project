<?php
/**
 * Created by PhpStorm.
 * User: Folag Technologies
 * Date: 6/3/2018
 * Time: 4:57 PM
 * Client: Alajo Online
 */


$dbname = "macfinhc_db";
$dbhost = "localhost";
$dbuser = "macfinhc_usr";
$dbpass = "8J9kepY66f";

$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

if($conn ->connect_errno){
    echo "Cannot Connect to Database".mysqli_error($conn);
}

if(isset($_POST['contactform'])){

	$fullname = mysqli_real_escape_string($conn, (trim($_POST['fullname'])));
	$email = mysqli_real_escape_string($conn, (trim($_POST['email'])));
	$subject = mysqli_real_escape_string($conn, (trim($_POST['subject'])));
	$phone = mysqli_real_escape_string($conn, (trim($_POST['phone'])));
	$message = mysqli_real_escape_string($conn, (trim($_POST['message'])));
	
	
	$targetemail = 'info@macfinh.com';
	
	$fullmessage = 'Name : ' . $fullname . '<br />' .

    'Email : ' . $email . '<br />' .
    'Phone Number : ' . $phone . '<br />' .

    'Message : ' . $message . '<br />';
    
    $from= "$email";
	$header = "$fullname: $subject";
	//$message = "<div> <p>$message </p><p> $phone</p></div>";

	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
	// More headers
	$headers .= 'From: <' . $email . '>' . "\r\n" .
    'Reply-To: ' . $email . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
    $headers .= "MESSAGE FROM $fullname ";
    //send email

   $send =  mail($targetemail, "Contact from " .$email, $fullmessage, $headers);
    
    if($send){

			print "<script>alert(\"Thanks $fullname for your message, you will be contacted soonest\");window.history.back();</script>";
			
	}

		else{

            print "<script>alert(\"sorry, message not sent\");window.history.back();</script>";
			
		}
}

?>