<?php
$startYear = 2018;
$thisYear = date('Y');
if ($thisYear > $startYear) {
	$thisYear = date('Y');
	$copyright = "$startYear &ndash; $thisYear";
} else {
	$copyright = $startYear;
}

/* Then at the footer code where "&copy 2017" is, write in place of 2017
this php code (<?php echo $copyright; ?>)
*/ 
?> 
		<div id="footer"> 

			<div id="copyright">
				&copy; Copyright <?php echo $copyright; ?> by MACFINH NIG LIMITED. All rights reserved.
			</div>
	
			<div id="sociallink">
		
				<a href="http://www.gmail.com"><img src="images/gmail.jpg" /></a>
				<a href="http://www.yahoomail.com"><img src="images/email.jpg" /></a>
				<a href="http://www.youtube.com"><img src="images/youtube.jpg" /></a>
				<a href="http://www.twitter.com"><img src="images/twitter.jpg" /></a>
				<a href="http://www.facebook.com"><img src="images/facebook.jpg" /></a>
			</div>
	
		</div>
