<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MACFINH NIG LIMITED</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="customMacfinh.css" rel="stylesheet">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="main.js"></script>

  </head>

  <body>

		

			<!--CODES FOR HEADER AND NAVIGATION BAR -->
	
	<div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

		<div class="well well-sm" style="background: blue; color: white; border: none;">
			<div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
				<h6><span class="glyphicon glyphicon-envelope">info@macfinh.com, support@macfinh.com  <span class="glyphicon glyphicon-earphone">0802-973-3506, 0813-359-1444, 0803-302-7085</span></span></h6>
			</div>
			<div style="float: right; margin-top: -12px; margin-right: 90px;">
				<a href="http://www.facebook.com"><img src="images/facebook.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.gmail.com"><img src="images/gmail.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.youtube.com"><img src="images/youtube.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.twitter.com"><img src="images/twitter.jpg" style="width: 15px; height: 15px;" /></a>
			</div>
		</div>

		<div class="container col-sm-12" style="margin-top: -20px;">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
				<a href="#" class="navbar-brand"><img class="img-responsive" src="images/maclogo.png" style="height: 40px; width: 40px; margin-top: -10px; " /><h5 style="margin-left: 50px; margin-top: -25px; color: red;"><strong>MACFINH NIG LIMITED</strong></h5></a>

			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php">Home</a></li>
				<li class="active"><a href="about.php">About Us</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="contact.php">Contact Us</a></li>				
			</ul>

		</div>
	</div>
</div>

<p></p>br></p>
<p></p>br></p> 


<!--<div class="wrapper"> -->

		
	<!--Code For jumbotron that contain vision, mission statement, and aim. -->
	
			<div class="container">
				<div class="jumbotron" style="background: #B0E2FF;">
					<p class="btn btn-lg btn-primary"><strong>Our Vission</strong></p>			
					<p style="font-size: 16px;">
						To be a leading industrial institution, with a dedicated staff that attracts the deserving interests of customers across Nigeria and the world.
					</p>

					<p class="btn btn-lg btn-primary"><strong>Our Mission</strong></p>
					<p style="font-size: 18px;">
					 	To consistently meet and exceed customers’ expectations by providing valued solutions through professional and highly motivated people, delivering excellent performance in all markets where we operate and providing efficient services and sincere assurances to shareholders.
					</p>

					<p class="btn btn-lg btn-primary"><strong>Our Work Philosophy</strong></p>
					<p style="font-size: 18px;">
					 	We recognize that the world needs all the technological advancement we can develop in every potential form for the benefit of a better and safer work environment. That is why our employees work to responsibly develop and ensure reliable techniques that engender the promises of the future, thus situating us to meet global needs.</br>

					 	We believe in the philosophy: <b>“Think locally, act globally”.</b>
					</p>
				 </div>
			</div>

			<div class="container">
				<div class="jumbotron" style="background: #FFF0F5;">
					<!--Code For SECTION that contain FOUNDER'S PIX AND SPEECH -->

					<img src="images/ceo1.jpg" class="pull-left img-thumbnail img-responsive" style="width:155px; height: 190px; margin-left: 0px;" /><!--center-block, pull-left, pull-right-->
						
					<h3 style="color: #8B008B;"><b>CEO's Speech</b></h3>
					<p style="font-size: 16px;">
						I welcome everyone to our official website. MACFINH Nigeria Limited, a result-oriented labour provider, commenced operations with Guinness Nigeria Plc in June 1993 by and through its founder Chief MAURICE OBI EJIOFOR of Obosi, Anambra State, Nigeria. The name MACFINH is an acronym coined from an array of initials.  Chief Maurice Obi Ejiofor as the Chief Executive/Managing Director was a former Guinness Nig Plc. Staff with an enviable chain of distinctions. He worked as production supervisor and manager for Guinness. He has worked in all areas of production and warehousing. He’s an astute philanthropist and a devout Christian. </br>
					</p>
					<p style="color: #9B30FF;">Shared values:</p>
					<p style="font-size: 16px;">
						•	We are a labour-provider service organization.</br>
						•	Our staff, community and the physical environment are the core constituents of our value system and services.</br>
						•	We seek to carve the image of a strong stakeholder and player in the national and global wealth creation process.</br>
						•	Our goal is to build a culture of excellence in collaboration with like-minded institutions and organizations in Nigeria and around the world.</br>
					</p>

					<p style="color: #9B30FF;">Integrity:</p>
					<p style="font-size: 16px;">
						We pride ourselves on the enviable marks of honesty, truthfulness and perseverance. This is predicated on our moral obligations as a partner to our customers, stakeholders and employees.
					</p>

					<p style="color: #9B30FF;">Competence:</p>
					<p style="font-size: 16px;">
						Having been tried and tested, with the benefits of hindsight, we are equipped, (including agronomy), with clusters of highly relevant abilities, commitments, knowledge and skills that enable us effectively meet and exceed our clients' expectations in a security-conscious environment.</br>
						We have successfully conducted operations in (and continue to operate in some of the following locations): Ikeja, Lagos; Ilishan, Ogun State; Ogba, Lagos; WEMCO, Lagos; Henry Carr, Lagos; Ashade warehouse, Ikeja; Agbor Road, Benin City; ACME Road, Lagos; Agbara, Ogun State; Daily Times, Lagos; JOF, Lagos.
					</p>

					<p style="font-size: 16px;">
						We do professional export-loadings to Ghana, South Africa, U.K., Liberia, etc. these loadings include various product like Stout, Orijin, Snapp, Dubic Malt, Malta Guinness and a long chain of spirit products. Other products include: Foreign Extra Stout, Harp Lager Beer, Guinness Extra Smooth, Satzenbrau, Harp Lime, Armstrong Black Lager, Dubic Extra Lager, Star Lager, Gulder lager beer, Legend Extra Stout, Heineken Lager, Goldberg Lager, Life Continental Lager, Smirnoff, McDowell’s, Johnnie Walker and Gordon.
					</p>

					<p style="font-size: 16px;">
						Finally, I am appealing to you to trust us with your result-oriented labour provider and achieve the best.
					</p>

				</div>	
			</div>

			<div class="container">
				<div class="jumbotron" style="background: #F0F8FF;">

					<img src="images/stanley111.jpg" class="pull-left img-thumbnail img-responsive" style="width:175px; height: 190px; margin-left: 0px;" /><!--center-block, pull-left, pull-right-->
						
					<h3 style="color: red;">General Manager's Speech</h3>
					<p style="font-size: 16px;">
						<b style="color: #DC143C;">Leadership:</b> We are a leading industrial institution and take leadership role within the realm of industrial service provision that involves labor, knowledge and technical methodology. This enables us serve our clients better, as we currently stand out as the foremost service-oriented labour provider to Guinness Nigeria Plc. with more than twenty-three(23) years of unparalleled dedication and delivery.</br>
						<b style="color: #DC143C;">Accountability:</b> We hold dear our obligations and activities; we deliver on our promises; accept faults of our makings in a transparent and comprehensive manner in accordance with international best practices.</br>
						<b style="color: #DC143C;">Passion:</b> We are a team of professional, dedicated and relentlessly devoted work-force in pursuit of excellence by providing valued and surefire solutions to problems and situations we experience as well as those envisaged.</br>
					</p>

				</div>	
			</div>

			<div class="container">
				<div class="jumbotron" style="background: #F0FFF0;">

					<img src="images/edmond11.jpg" class="pull-left img-thumbnail img-responsive" style="width:210px; height: 190px; margin-left: 0px;" /><!--center-block, pull-left, pull-right-->
						
					<h3 style="color: red;">Admin. Manager's Speech</h3>
					<p style="font-size: 16px;">
						We trace our humble beginnings to 1983, when our Chief Executive Officer was employed with a contracting firm that worked for Guinness Nigeria Limited.
						A few other experts that constitute the bedrock of MACFINH’s workforce today were employed with various contracting firms working for Guinness. These individuals acquired variety of technical skills and acknowledge that have come to bear in MACFINH’s favor, compliant with contemporary work environment.</br>
						
						<b style="color: #DC143C;">Manpower Training and Development:</b>
						MACFINH maintains and operates a rigorous personnel and skills training program for all categories of workers. This includes the exportation of training expertise to outsourcing companies and institutions.
					</p>

				</div>	
			</div>



	<!--Code For footer is in "footer.php" using server-side include method-->

<?php include 'includes/footer.php'; ?>



			<script src="js/jquery.min.js"></script>
  		<script src="js/bootstrap.min.js"></script>
		
    </body>
</html>
