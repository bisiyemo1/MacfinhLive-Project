<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MACFINH NIG LIMITED</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="customMacfinh.css" rel="stylesheet">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="main.js"></script>

  </head>

  <body data-spy="scroll" data-target="#mainNavbar" data-offset="70">

		

			<!--CODES FOR HEADER AND NAVIGATION BAR -->
	
	<div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

		<div class="well well-sm" style="background: blue; color: white; border: none;">
			<div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
				<h6><span class="glyphicon glyphicon-envelope">info@macfinh.com, support@macfinh.com  <span class="glyphicon glyphicon-earphone">0802-973-3506, 0813-359-1444, 0803-302-7085</span></span></h6>
			</div>
			<div style="float: right; margin-top: -12px; margin-right: 90px;">
				<a href="http://www.facebook.com"><img src="images/facebook.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.gmail.com"><img src="images/gmail.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.youtube.com"><img src="images/youtube.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.twitter.com"><img src="images/twitter.jpg" style="width: 15px; height: 15px;" /></a>
			</div>
		</div>

		<div class="container col-sm-12" style="margin-top: -20px;">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
				<a href="#" class="navbar-brand"><img class="img-responsive" src="images/maclogo.png" style="height: 40px; width: 40px; margin-top: -10px; " /><h5 style="margin-left: 50px; margin-top: -25px; color: red;"><strong>MACFINH NIG LIMITED</strong></h5></a>

			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="about.php">About Us</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="contact.php">Contact Us</a></li>				
			</ul>

		</div>
	</div>
</div>

<p></p>br></p>
<p></p>br></p> 


<!--<div class="wrapper"> -->

		<!--Code for Column Picture slide show-->

<div class="container">
	<div class="row">
			
			<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
				<div class="panel-body">

					<div class="col-sm-4">
						<div style="margin-bottom:3px; min-height:350px; background-color:#48D1CC; text-align:center; font-size:16px; font-family:pristina; color: white;">
							<b>EXPORT CONTAINER LOADING (GANA MALT)</b>
							<div>
								<img src="images/export1.jpg" class="img-responsive" style="height: 275px; width: 350px; margin-left: 0px; margin-top:25px;" />
							</div>
						</div>
					</div>


					<div class="col-sm-4"> <!--Iff the image is big use <div class="col-md-8 col-md-offset-2">-->
						
						<div id="imageCarousel" class="carousel slide" data-wrap="true" data-interval="4000"><!--Instead of javascript code for sliding you can use (data-ride="carousel")-->
							<ol class="carousel-indicators">
								<li data-target="#imageCarousel" data-slide-to="0" class="active"></li>
								<li data-target="#imageCarousel" data-slide-to="1"></li>
								<li data-target="#imageCarousel" data-slide-to="2"></li>
								<li data-target="#imageCarousel" data-slide-to="3"></li>
								<li data-target="#imageCarousel" data-slide-to="4"></li>
							</ol>
							<div class="carousel-inner img-responsive" style="height: 360px; width: 340px;">
								<div class="item active" style="height: 370px; width: 340px;">
									<img src="images/conveyor11.jpg" class="img-responsive" style="height: 340px; width: 350px;" />
									<div class="carousel-caption">
										<p>HIGHLY TRAINED CONVEYOR OPERATOR</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/IMG11.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>TRAINED FORKLIFT OPERATOR</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/IMG5.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>EXPERIENCED MACHINE OPERATOR</p>
									</div>
								</div>								

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/fork1.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>MECHANICAL STACKING FORKLIFT OPERATION</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/quaterly1.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>QUATERLY TRAINING ON STOCK VERIFICATION</p>
									</div>
								</div>

							</div>
							<a href="#imageCarousel" class="carousel-control left" data-slide="prev">
								<span class="glyphicon glyphicon-chevron-left"></span>
							</a>

							<a href="#imageCarousel" class="carousel-control right" data-slide="next">
								<span class="glyphicon glyphicon-chevron-right"></span>
							</a>
						</div>

					</div>


					<div class="col-sm-4">
						<div style="margin-bottom:3px; min-height:350px; background-color:#48D1CC; text-align:center; font-size:16px; font-family:pristina; color: white;">
							<b>STOCK AT IKENNE, OGUN STATE, NIGERIA</b> 
							<div>
								<img src="images/ikenne1.jpg" class="img-responsive" style="height: 275px; width: 350px; margin-left: 0px; margin-top:25px;" />
							</div>
						</div>
					</div>

				</div>				
			</div>

<!--Code for Column of macfinh executives and management team-->

	<div class="container">
		<div class="row">
					<div class="col-sm-6">
						<div style="margin-bottom:3px; min-height:350px; background-color:#48D1CC; text-align:center; font-size:17px; font-family:pristina; color: white;">
							<b>MACFINH EXECUTIVES</b>
							<div>
								<img src="images/executives1.jpg" class="img-responsive" style="height: 300px; width: 600px; margin-left: 0px;" />
							</div>
						</div>
					</div>

					<div class="col-sm-6">
						<div style="margin-bottom:3px; min-height:350px; background-color:#48D1CC; text-align:center; font-size:17px; font-family:pristina; color: white;">
							<b>MANAGEMENT TEAM</b>
							<div>
								<img src="images/management1.jpg" class="img-responsive" style="height: 300px; width: 600px; margin-left: 0px;" />
							</div>
						</div>
					</div>
		</div>				
	</div>
			
	<!--Code for Column of about, gallery and contact links-->
		
			<div class="container">
				<br /><br />
				<div class="row">
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<h3><a style="color: white;">About</a></h3> "About page is specially design to know us better, what we stand for, vision, mission, our impact globally and..."<a href="about.php" style="color: blue;">more</a>"
						</div>
					</div>
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<h3><a style="color: white;">Gallery</a></h3>Gallery page is specially design to give you access to viewing our works, the impacts we have made globally and..."<a href="gallery.php" style="color: blue;">more</a>"
						</div>
					</div>
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<h3><a style="color: white;">Contact Us</a></h3> "Contact page is specially design to give you easy access to get in touch with us, for enquiry about anything and..."<a href="contact.php" style="color: blue;">more</a>"
						</div>
					</div>
				</div>
			</div>			
	</div>				
</div>
		
<!--</div>-->


	<!--Code For footer is in "footer.php" using server-side include method-->

<?php include 'includes/footer.php'; ?>  



			<script src="js/jquery.min.js"></script>
  		<script src="js/bootstrap.min.js"></script>
  		<script type="text/javascript">
  				/*Javascript for tutorial 51*/
  			$(document).ready(function () {
  				$('#imageCarousel').carousel();
  			});

  		</script> 
		
    </body>
</html>