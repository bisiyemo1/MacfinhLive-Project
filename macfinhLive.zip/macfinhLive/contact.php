<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MACFINH NIG LIMITED</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="customMacfinh.css" rel="stylesheet" />
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="main.js"></script>

  </head>

  <body>	

			<!--CODES FOR HEADER AND NAVIGATION BAR -->
	
	<div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

		<div class="well well-sm" style="background: blue; color: white; border: none;">
			<div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
				<h6><span class="glyphicon glyphicon-envelope">info@macfinh.com, support@macfinh.com  <span class="glyphicon glyphicon-earphone">0802-973-3506, 0813-359-1444, 0803-302-7085</span></span></h6>
			</div>
			<div style="float: right; margin-top: -12px; margin-right: 90px;">
				<a href="http://www.facebook.com"><img src="images/facebook.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.gmail.com"><img src="images/gmail.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.youtube.com"><img src="images/youtube.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.twitter.com"><img src="images/twitter.jpg" style="width: 15px; height: 15px;" /></a>
			</div>
		</div>

		<div class="container col-sm-12" style="margin-top: -20px;">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
				<a href="#" class="navbar-brand"><img class="img-responsive" src="images/maclogo.png" style="height: 40px; width: 40px; margin-top: -10px; " /><h5 style="margin-left: 50px; margin-top: -25px; color: red;"><strong>MACFINH NIG LIMITED</strong></h5></a>

			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About Us</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li class="active"><a href="contact.php">Contact Us</a></li>				
			</ul>

		</div>
	</div>
</div>

<p></p>br></p>
<p></p>br></p> 


<!--<div class="wrapper"> -->



<!-- contact form section -->

<div class="container">
	<div class="row">
		<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
			<div class="panel-body">
				<div class="col-sm-5">	
						<div class="well">
							<h4><center style="color:red;">Contact Form</center></h4>

								<form action="contact.php" method="post" name='contactform' id='contactform'>
										<p>
										<label for='fullname'>Your Names: </label><br/>
										<input type='text' name='fullname' placeholder="Enter Your Name" />
										</p>
										
										<p>
										<label for='address'>Phone number: </label><br/>
										<input type='number' name='phone' placeholder="Enter Your Phone Number" />
										</p>
										
										<p>
										<label for='email'>Email Address:</label><br/>
										<input type='text' name='email' placeholder="Enter Your Email Address" />
										</p>
										
										<p>
										<label for='email'>Subject:</label><br/>
										<input type='text' name='subject' placeholder="Enter Your Subject" />
										</p>
										
										<p>
										<label for='email'>Message:</label><br/>
										<textarea name="message" rows="5" cols="30"  placeholder="Enter Your Message">  
										</textarea> 
										</p>
										
										<input type='submit' class="btn-success" name='submit' value='submit form' />
								</form>

						</div>
				</div>
	
					<div class="container">
						<div class="row">
							<div class="col-sm-6">
								<div style="background-color: #BFEFFF; margin-bottom:3px; min-height:450px;
									background-color:#BFEFFF; font-size:25px; font-family:pristina;">
									<br/>
									<marquee style="color:red;">The Company's Contact Details</marquee>
									
									<p>Our highly esteemed customers worldwide, you can do well to contact us through the followings:</p>
									 <p><h3 style="color:red;">Contact numbers:</h3> 0802-973-3506, 0813-359-1444, 0803-302-7085</p> 
									 <p><h3 style="color:red;">Email:</h3> info@macfinh.com, support@macfinh.com</p>
									 <p style="color: red;">The company's headquarters address is shown below:</p>
									 <p>Gboyega Kilo Street, </br>
									   Ojodu, Lagos State,</br> 
									   Nigeria</p>									 
									
								</div>
							</div>
						</div>
					</div>
			</div>
		</div>
	</div>
</div>		

<!--</div>-->

			
	<!--Code For footer is in "footer.php" using server-side include method-->

<?php include 'includes/footer.php'; ?>


			<script src="js/jquery.min.js"></script>
  		<script src="js/bootstrap.min.js"></script>

    </body>
</html>
<?php



$dbname = "macfinhc_db";
$dbhost = "localhost";
$dbuser = "macfinhc_usr";
$dbpass = "8J9kepY66f";

$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

if($conn ->connect_errno){
    echo "Cannot Connect to Database".mysqli_error($conn);
}

if(isset($_POST['submit'])){

	$fullname = trim($_POST['fullname']);
	$email =trim($_POST['email']);
	$subject = trim($_POST['subject']);
	$phone = trim($_POST['phone']);
	$message = trim($_POST['message']);
	
	if((!$fullname) || (!$email) || (!$subject) || (!$phone) || (!$message)){
	    
	    		print "<script>alert(\"Please fill all the fields with necessary information. Thanks\");window.history.back();</script>";
	    
	}else{
	$targetemail = 'info@macfinh.com';
	
	$fullmessage = 'Name : ' . $fullname . '<br />' .

    'Email : ' . $email . '<br />' .
    'Phone Number : ' . $phone . '<br />' .

    'Message : ' . $message . '<br />';
    
    $from= "$email";
	$header = "$fullname: $subject";
	//$message = "<div> <p>$message </p><p> $phone</p></div>";

	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
	// More headers
	$headers .= 'From: <' . $email . '>' . "\r\n" .
    'Reply-To: ' . $email . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
    $headers .= "MESSAGE FROM $fullname ";
    //send email

   $send =  mail($targetemail, "Contact from " .$email, $fullmessage, $headers);
    
    if($send){

			print "<script>alert(\"Thanks $fullname for your message, you will be contacted soonest\");window.history.back();</script>";
			
	}

		else{

            print "<script>alert(\"sorry, message not sent\");window.history.back();</script>";
			
		}
}
}
?>
