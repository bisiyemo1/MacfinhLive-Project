<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MACFINH NIG LIMITED</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="customMacfinh.css" rel="stylesheet">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="main.js"></script>
  </head>

<body>

			<!--CODES FOR HEADER AND NAVIGATION BAR -->
	
	<div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

		<div class="well well-sm" style="background: blue; color: white; border: none;">
			<div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
				<h6><span class="glyphicon glyphicon-envelope">info@macfinh.com, support@macfinh.com  <span class="glyphicon glyphicon-earphone">0802-973-3506, 0813-359-1444, 0803-302-7085</span></span></h6>
			</div>
			<div style="float: right; margin-top: -12px; margin-right: 90px;">
				<a href="http://www.facebook.com"><img src="images/facebook.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.gmail.com"><img src="images/gmail.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.youtube.com"><img src="images/youtube.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.twitter.com"><img src="images/twitter.jpg" style="width: 15px; height: 15px;" /></a>
			</div>
		</div>

		<div class="container col-sm-12" style="margin-top: -20px;">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
				<a href="#" class="navbar-brand"><img class="img-responsive" src="images/maclogo.png" style="height: 40px; width: 40px; margin-top: -10px; " /><h5 style="margin-left: 50px; margin-top: -25px; color: red;"><strong>MACFINH NIG LIMITED</strong></h5></a>

			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About Us</a></li>
				<li class="active"><a href="gallery.php">Gallery</a></li>
				<li><a href="contact.php">Contact Us</a></li>				
			</ul>

		</div>
	</div>
</div>

<p></p>br></p>
<p></p>br></p>


<!--CODE FOR DISPLAY OF PRODUCTS (PORDUCTS SECTION) -->

		<div class="col-md-12">
			<div class="panel panel-info">
				<div class="panel panel-heading">Our Products and Services</div>
				<div class="panel-body">

						<div class="panel panel-info">
								<div class="panel-body">
									<div class="col-sm-offset-4 col-sm-4">
										<div class="customDiv">VIDEO CLIP OF OUR SERVICES
							       			<video src="images/video.mp4" class="img-responsive" width="580" height="210" controls loop style="height: 450px; width: 400px;"></video>	
										</div>
									</div>
								</div>
						</div>

						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG11.jpg" class="thumbnail">
								<img src="images/IMG11.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG6.jpg" class="thumbnail">
								<img src="images/IMG6.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG5.jpg" class="thumbnail">
								<img src="images/IMG5.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG12.jpg" class="thumbnail">
								<img src="images/IMG12.jpg" style="height: 300px; width: 450px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG14.jpg" class="thumbnail">
								<img src="images/IMG14.jpg" style="height: 300px; width: 450px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG10.jpg" class="thumbnail">
								<img src="images/IMG10.jpg" style="height: 300px; width: 450px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG16.jpg" class="thumbnail">
								<img src="images/IMG16.jpg" style="height: 300px; width: 450px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG18.jpg" class="thumbnail">
								<img src="images/IMG18.jpg" style="height: 300px; width: 450px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG8.jpg" class="thumbnail">
								<img src="images/IMG8.jpg" style="height: 300px; width: 450px;" />
							</a>
						</div>

						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG4.jpg" class="thumbnail">
								<img src="images/IMG4.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG15.jpg" class="thumbnail">
								<img src="images/IMG15.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG17.jpg" class="thumbnail">
								<img src="images/IMG17.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG19.jpg" class="thumbnail">
								<img src="images/IMG19.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG20.jpg" class="thumbnail">
								<img src="images/IMG20.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG21.jpg" class="thumbnail">
								<img src="images/IMG21.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG22.jpg" class="thumbnail">
								<img src="images/IMG22.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG23.jpg" class="thumbnail">
								<img src="images/IMG23.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG24.jpg" class="thumbnail">
								<img src="images/IMG24.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>

						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG25.jpg" class="thumbnail">
								<img src="images/IMG25.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG26.jpg" class="thumbnail">
								<img src="images/IMG26.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-4">	
							<a href="images/IMG27.jpg" class="thumbnail">
								<img src="images/IMG27.jpg" style="height: 450px; width: 350px;" />
							</a>
						</div>

				</div>
				<div class="panel-footer"></div>
			</div>
		</div>

		
	</div>
</div>

	<!--Code For footer is in "footer.php" using server-side include method-->

<?php include 'includes/footer.php'; ?>  

</body>


</html>

